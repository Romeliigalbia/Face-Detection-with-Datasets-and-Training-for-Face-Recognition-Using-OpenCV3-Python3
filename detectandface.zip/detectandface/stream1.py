# -*- coding: cp1252 -*-
#import os
#import urllib.request
import cv2
#import numpy as np
#from PIL import Image

#recognizer=cv2.face.LBPHFaceRecognizer_create();
path='dataset'

def show_webcam(mirror=False):
    cap = cv2.VideoCapture(1)
    cap.open(1)
    a=0
#   cap = "http://192.168.1.43:8080/shot.jpg"
#   id = input('enter user id: ')
    faceDetect=cv2.CascadeClassifier('clasifier/haarcascade_frontalface_default.xml')
#    sampleNum=0

    while True:
        a = a+1
#        imgResp=urllib.request.urlopen(cap)
#        imgNp=np.array(bytearray(imgResp.read()),dtype=np.uint8)
#        img=cv2.imdecode(imgNp,-1)
        check, img = cap.read()
        print(check)
        print(img)
        gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
        faces=faceDetect.detectMultiScale(gray,1.3,5,minSize=(30,30), flags=cv2.CASCADE_SCALE_IMAGE)
        for(x,y,w,h) in faces:
#            sampleNum = sampleNum+1
            cv2.rectangle(img, (x,y),(x+w,y+h),(125,255,125),2)
#            roi_gray= gray[y:y+h, x:x+w]
#            roi_color= img[y:y+h, x:x+w]
#            eyes = eye_cascade.detectMultiScale(roi_color)
#            for (ex,ey,ew,eh) in eyes:
#                cv2.rectangle(roi_color,(ex,ey),(ex+ew,ey+eh),(0,255,0),2)
#        cv2.imwrite("dataSet/User."+str(id)+"."+str(sampleNum)+".jpg",gray[y:y+h,x:x+w])
        if mirror: 
            img = cv2.flip(img, 1)
        cv2.imshow('frame', img)

        if cv2.waitKey(100) & 0xff == ord('q'):
            break
 #       elif(sampleNum>20):
 #           break
    
    print(a)
    cap.release()
    cv2.destroyAllWindows()

def main():
    show_webcam(mirror=True)
    

#def getImagesWithID(path):
#    imagePaths=[os.path.join(path,f) for f in os.listdir(path)]
#    faces=[]
#    IDs=[]
#    for imagePath in imagePaths:
#        faceImg=Image.open(imagePath).convert('L');
#        faceNp=np.array(faceImg,'uint8')
#        ID=int(os.path.split(imagePath)[-1].split('.')[1])
#        faces.append(faceNp)
#        IDs.append(ID)
#        cv2.imshow('training',faceNp)
#        cv2.waitKey(10)
#    return np.array(IDs), faces
#Ids, faces=getImagesWithID(path)
#recognizer.train(faces,Ids)
#recognizer.save('recognizer/trainingData.yml')
#exit(0)
#print('done training')
#

if __name__=='__main__':
    main()
#    getImagesWithID(path)