# -*- coding: utf-8 -*-
import cv2
#import os
#import sqlite3
import pymysql
#import pickle
#import numpy as np
#from PIL import Image

def recognize(mirror=False):
    
    
    faceDetect=cv2.CascadeClassifier('clasifier/haarcascade_frontalface_default.xml')
    rec = cv2.face.LBPHFaceRecognizer_create();
    rec.read("recognizer\\trainingData.yml")
#    path = "datasets"
    
    def getProfile(id):
        
        conn = pymysql.connect(host="localhost", user="root", passwd="", db="try")
        myCursor = conn.cursor()
        cmd="SELECT * FROM `People` WHERE ID="+str(id)
        myCursor.execute(cmd)
        profile=None
        for row in myCursor:
            profile=row
        conn.close()
        return profile
#        conn=sqlite3.connect("FaceBase.db")
#        cmd="SELECT * FROM [People   ] WHERE ID="+str(id)
#        cursor=conn.execute(cmd)
#        profile=None
#        for row in cursor:
#            profile=row
#        conn.close()
#        return profile
    
    cam = cv2.VideoCapture(1);
    cam.open(1)
    id = 0 
    fontface = cv2.FONT_HERSHEY_COMPLEX
    while True:
        
        check, img=cam.read()
        if mirror: 
            img = cv2.flip(img, 1)
        print(check)
        print(img)
        gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
        faces=faceDetect.detectMultiScale(gray,1.3,5,minSize=(100,100), flags=cv2.CASCADE_SCALE_IMAGE);
        for(x,y,w,h) in faces:
            id,conf=rec.predict(gray[y:y+h,x:x+w])
            cv2.rectangle(img,(x,y),(x+w,y+h),(205,0,0),2)
            profile=getProfile(id)
            if(profile!=None):
                cv2.putText(img,str(profile[1]),(x,y+h+30), fontface,0.6,(0,255,255),2)
                cv2.putText(img,str(profile[2]),(x,y+h+60), fontface,0.6,(0,255,255),2)
                cv2.putText(img,str(profile[3]),(x,y+h+90), fontface,0.6,(0,255,255),2)
                cv2.putText(img,str(profile[4]),(x,y+h+120), fontface,0.6,(0,255,255),2)
        
        cv2.imshow('Face', img);
        if cv2.waitKey(100) & 0xff == ord('q'):
                break;
            
    cam.release()
    cv2.destroyAllWindows()

def main():
    recognize(mirror=True)
    
if __name__ =='__main__':
    main()
    
        