import os
import cv2
import numpy as np
import pymysql
from PIL import Image

def detectandtrain(mirror=False):
    path='datasets'
    cap = cv2.VideoCapture(1)
    cap.open(1)
    a=0
    db = pymysql.connect("localhost","root","","try",charset='utf8mb4', cursorclass=pymysql.cursors.DictCursor)
    print ("Connected to Database!!")
    
    try:
        id = input('enter user id: ')
        
        name = input('enter user name: ')
        
        cursor = db.cursor()
        cursor.execute("DROP TABLE IF EXISTS people")
    
        # Create table as per requirement
        sql = """CREATE TABLE people (
           `ID` INT(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
           `Name`  VARCHAR(255),
           `Age` INT(11),  
           `Gender` TEXT,
           `CriminalRecords` TEXT)"""
        
        cursor.execute(sql)
        
    #    sqlinsert = """
    
        isRecordExist=0
        for row in cursor:
            isRecordExist=1
        if(isRecordExist==1):
            cmd="UPDATE `people` SET Name="+str(name)+" WHERE ID="+str(id)
        else:
            cmd="INSERT INTO `people` (ID,Name) VALUES ('"+str(id)+"','"+str(name)+"')"
            cursor.execute(cmd)
        db.commit()
            
    #        conn=sqlite3.connect("FaceBase.db")
    #        cmd="SELECT * FROM [People   ] WHERE ID="+str(Id)
    #        cursor=conn.execute(cmd)
    #        isRecordExist=0
    #        for row in cursor:
    #            isRecordExist=1
    #        if(isRecordExist==1):
    #            cmd="UPDATE [People   ] SET Name="+str(Name)+" WHERE ID="+str(Id)
    #        else:
    #            cmd="INSERT INTO [People   ](ID,Name) VALUES ('"+str(Id)+"','"+str(Name)+"')"
    #        conn.execute(cmd)
    #        conn.commit()
    #        conn.close()
        
    #    InsertOrUpdate(id,name)
    finally:
        db.close()
    
    faceDetect=cv2.CascadeClassifier('clasifier/haarcascade_frontalface_default.xml')
#    eye_cascade = cv2.CascadeClassifier('clasifier/haarcascade_eye.xml')
    sampleNum=0

    while True:
        a = a+1
        check, img = cap.read()
        
        if mirror: 
            img = cv2.flip(img, 1)
        print(check)
        print(img)
        gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
        faces=faceDetect.detectMultiScale(gray,1.3,5,minSize=(30,30), flags=cv2.CASCADE_SCALE_IMAGE);
        for(x,y,w,h) in faces:
            sampleNum = sampleNum+1
            cv2.rectangle(img, (x-50,y-50),(x+w+50,y+h+50),(125,255,125),2)
            cv2.imwrite("datasets/User."+str(id)+"."+str(sampleNum)+".jpg",gray[y:y+h,x:x+w])
        cv2.imshow('frame', img)
    
        if cv2.waitKey(100) & 0xff == ord('q'):
            break
        elif(sampleNum>50):
            break
    
    print(a)
    cap.release()
    cv2.destroyAllWindows()
    
    recognizer=cv2.face.LBPHFaceRecognizer_create();

    path='datasets'
    def getImagesWithID(path):
        imagePaths=[os.path.join(path,f) for f in os.listdir(path)]
        faces=[]
        IDs=[]
        for imagePath in imagePaths:
            faceImg=Image.open(imagePath).convert('L');
            faceNp=np.array(faceImg,'uint8')
            ID=int(os.path.split(imagePath)[-1].split('.')[1])
            faces.append(faceNp)
            IDs.append(ID)
            cv2.imshow('training',faceNp)
            cv2.waitKey(10)
        return np.array(IDs), faces
    Ids, faces=getImagesWithID(path)
    recognizer.train(faces,Ids)
    recognizer.write('recognizer/trainingData.yml')
    cv2.destroyAllWindows()

def main():
    detectandtrain(mirror=True)
#        
    
    
if __name__=='__main__':
    main()
